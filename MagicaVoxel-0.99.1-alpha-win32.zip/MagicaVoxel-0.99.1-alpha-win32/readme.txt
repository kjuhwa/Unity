[MagicaVoxel : 8-bit Voxel Editor & Renderer]
================================
date    : 3/11/2018

version : 0.99.1a

os      : Win32, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
